"""
Projects app package.
"""
