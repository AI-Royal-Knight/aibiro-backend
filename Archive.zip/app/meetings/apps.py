from django.apps import AppConfig


class MeetingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app.meetings'
    verbose_name = 'AccrediSure Meetings'
